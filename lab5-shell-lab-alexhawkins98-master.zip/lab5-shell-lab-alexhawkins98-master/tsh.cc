// 
// tsh - A tiny shell program with job control
// 
// <Alexander Hawkins 105070938>
//

using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <string>

#include "globals.h"
#include "jobs.h"
#include "helper-routines.h"

//
// Needed global variable definitions
//

static char prompt[] = "tsh> ";
int verbose = 0;

//
// You need to implement the functions eval, builtin_cmd, do_bgfg,
// waitfg, sigchld_handler, sigstp_handler, sigint_handler
//
// The code below provides the "prototypes" for those functions
// so that earlier code can refer to them. You need to fill in the
// function bodies below.
// 

void eval(char *cmdline);
int builtin_cmd(char **argv);
void do_bgfg(char **argv);
void waitfg(pid_t pid);

void sigchld_handler(int sig);
void sigtstp_handler(int sig);
void sigint_handler(int sig);

//
// main - The shell's main routine 
//

int main(int argc, char *argv[]) 
{
  int emit_prompt = 1; // emit prompt (default)

  //
  // Redirect stderr to stdout (so that driver will get all output
  // on the pipe connected to stdout)
  //
  dup2(1, 2);

  /* Parse the command line */
  char c;
  while ((c = getopt(argc, argv, "hvp")) != EOF) {
    switch (c) {
    case 'h':             // print help message
      usage();
      break;
    case 'v':             // emit additional diagnostic info
      verbose = 1;
      break;
    case 'p':             // don't print a prompt
      emit_prompt = 0;  // handy for automatic testing
      break;
    default:
      usage();
    }
  }

  //
  // Install the signal handlers
  //

  //
  // These are the ones you will need to implement
  //
  Signal(SIGINT,  sigint_handler);   // ctrl-c
  Signal(SIGTSTP, sigtstp_handler);  // ctrl-z
  Signal(SIGCHLD, sigchld_handler);  // Terminated or stopped child

  //
  // This one provides a clean way to kill the shell
  //
  Signal(SIGQUIT, sigquit_handler); 

  //
  // Initialize the job list
  //
  initjobs(jobs);

  //
  // Execute the shell's read/eval loop
  //
  for(;;) {
    //
    // Read command line
    //
    if (emit_prompt) {
      printf("%s", prompt);
      fflush(stdout);
    }

    char cmdline[MAXLINE];

    if ((fgets(cmdline, MAXLINE, stdin) == NULL) && ferror(stdin)) {
      app_error("fgets error");
    }
    //
    // End of file? (did user type ctrl-d?)
    //
    if (feof(stdin)) {
      fflush(stdout);
      exit(0);
    }

    //
    // Evaluate command line
    //
    eval(cmdline);
    fflush(stdout);
    fflush(stdout);
  } 

  exit(0); //control never reaches here
}
  
/////////////////////////////////////////////////////////////////////////////
//
// eval - Evaluate the command line that the user has just typed in
// 
// If the user has requested a built-in command (quit, jobs, bg or fg)
// then execute it immediately. Otherwise, fork a child process and
// run the job in the context of the child. If the job is running in
// the foreground, wait for it to terminate and then return.  Note:
// each child process must have a unique process group ID so that our
// background children don't receive SIGINT (SIGTSTP) from the kernel
// when we type ctrl-c (ctrl-z) at the keyboard.
//

void eval(char *cmdline) 
{
  /* Parse command line */
  //
  // The 'argv' vector is filled in by the parseline
  // routine below. It provides the arguments needed
  // for the execve() routine, which you'll need to
  // use below to launch a process.
  //
    char *argv[MAXARGS];
    pid_t pid; //Activate Process ID 'pg.755'
    struct job_t *jobp; //Assigning the job state '#include jobs.h'
    sigset_t masksignal; //Blocking and Unblocking signals method '#include <signal.h> pg. 764 & 765'

  //
  // The 'bg' variable is TRUE if the job should run
  // in background mode or FALSE if it should run in FG
  //
    int bg = parseline(cmdline, argv); 
    
    if (sigemptyset(&masksignal)) //If statement to check if the signal set is empty. & is a deferencer for the parseline indicator executed in the background 'pg. 765'
    {
        unix_error("Signal error."); //Give an error indicator. 'pg. 771'
    }
    
    
    if (sigaddset(&masksignal, SIGCHLD)) //If statement to add the SigChld into the signal set. 'pg. 757 + 765'
    {
        unix_error("Sigset error."); //Give an error indicator. 'pg. 763'
    }
    
    
    if (!builtin_cmd(argv)) //If statement to check if the preferred builtin command is not correct. If builtin_command returns 0, then the shell creates a child process and executes the requested program inside the child. If the user has asked for the program to run in the background, then the shell returns to the top of the loop and waits for the next command line. Otherwise, the shell uses the waitpid function to wait for the job to terminate. When the job terminates, the shell goes on to the next iteration. 'pg. 754 + 755'
    {
        sigprocmask(SIG_BLOCK, &masksignal, 0); //Blocking & Unblocking Signals 'pg. 764 + 765'
        
        if ((pid = fork()) <= 0) //If statement utilizing the fork function to make the child run the user job 'pg. 755'.
        {
            if (pid < 0) //If statement for execution of the child processor.
            {
                unix_error("forking error displayed."); //Give an error. 'pg. 763'
            }
            
            setpgid(0, 0); //The setpgid function changes the process group of process pid to pgid. This will ensure there is one process in the shell running in the foreground. Process group ID will match the child pid.
            
            sigprocmask(SIG_UNBLOCK, &masksignal, 0); //Blocking & Unblocking Signals 'pg. 764 + 765'
            
            execvp(argv[0], argv); //Safe Signal Handling 'pg. 767'
            
            printf("%s: Command not found\n", argv[0]); //Print command not found 'pg. 755'
            
            exit(0); //Exit 'pg. 755'
        }
        
        addjob(jobs, pid, bg ? BG : FG, cmdline); //Add a job being executed either in the foreground or background and avoiding sychronizaiton error 'pg. 777'
        
        sigprocmask(SIG_UNBLOCK, &masksignal, 0); //Blocking & Unblocking Signals 'pg. 764 + 765'
        
        if (!bg) //If statement for the Parent processor to wait for the foreground job to terminate 'pg. 755'
        {
            waitfg(pid); //The Parent processor waits for the foreground job to terminate.
        }
        
        else //Else
        {
            jobp = getjobpid(jobs, pid); //The job state is equal to the process ID.
            
            printf("[%d] (%d) %s", jobp->jid, jobp->pid, cmdline); //Print processing information 'pg. 755'.
        }
    }
    
    return; //Follow up with the builtin command function
}


/////////////////////////////////////////////////////////////////////////////
//
// builtin_cmd - If the user has typed a built-in command then execute
// it immediately. The command name would be in argv[0] and
// is a C string. We've cast this to a C++ string type to simplify
// string comparisons; however, the do_bgfg routine will need 
// to use the argv array as well to look for a job number.
//

int builtin_cmd(char **argv) 
{
    string cmd(argv[0]);
    
    if (cmd == "quit") //If the command is equivalent to quit 'pg,. 755'
    {
        exit(0); //Safe exit
    }
    
    else if (cmd == "bg" || cmd == "fg") //If the command is equivalent to bg (background) or fg (foreground) 'pg. 755 + 756'
    {
        do_bgfg(argv); //Execute the builtin bg and fg commands
        return 1; //Return 1
    }
    
    else if (cmd == "jobs") //If the command is equivalent to jobs 'pg. 755 + 756'
    {
        listjobs(jobs); //List the jobs
        return 1; //Return 1
    }
    
    else if (cmd == "&") //If the command is equivalent to & 'ignore singleton & pg. 755'
    {
        return 1; //Return 1.
    }
    
    
    return 0;     /* not a builtin command */
}

/////////////////////////////////////////////////////////////////////////////
//
// do_bgfg - Execute the builtin bg and fg commands
//

void do_bgfg(char **argv) 
{
  struct job_t *jobp=NULL;
    
  /* Ignore command if no argument */
  if (argv[1] == NULL)
  {
    printf("%s command requires PID or %%jobid argument\n", argv[0]);
    return;
  }
    
  /* Parse the required PID or %JID arg */
  if (isdigit(argv[1][0]))
  {
    pid_t pid = atoi(argv[1]);
      
    if (!(jobp = getjobpid(jobs, pid)))
    {
      printf("(%d): No such process\n", pid);
      return;
    }
  }
    
  else if (argv[1][0] == '%')
  {
    int jid = atoi(&argv[1][1]);
      
    if (!(jobp = getjobjid(jobs, jid)))
    {
      printf("%s: No such job\n", argv[1]);
      return;
    }
  }
    
  else
  {
    printf("%s: argument must be a PID or %%jobid\n", argv[0]);
    return;
  }

  //
  // You need to complete rest. At this point,
  // the variable 'jobp' is the job pointer
  // for the job ID specified as an argument.
  //
  // Your actions will depend on the specified command
  // so we've converted argv[0] to a string (cmd) for
  // your benefit.
  //
    string cmd(argv[0]);
    
    if (cmd != "fg" && cmd != "bg") //If the cmd doesn't equal the foreground + background 'trace09.txt + trace10.txt'.
    {
        unix_error("do_bgfg error"); //Give an error. 'pg. 763'.
    }
    
    else if (cmd == "fg") //If the cmd is the foreground
    {
        if(kill(-(jobp->pid), SIGCONT) < 0) //If pid is less than zero, then kill sends signal sig to every process group |pid| 'pg. 761 + 757'.
        {
            unix_error("do_bgfg: Kill error"); //Give an error. 'pg. 763'.
        }
        
        jobp->state = FG; //The job state is the foreground.
        waitfg(jobp->pid); //Manage signal handling.
        
    }
    
    else if (cmd == "bg") //If the cmd is the background
    {
        if (kill(-(jobp->pid), SIGCONT) < 0) //If pid is less than zero, then kill sends signal sig to every process group |pid| 'pg. 761 + 757'.
        {
            unix_error("do_bgfg: Kill error"); //Give an error. 'pg. 763'.
        }
        
        jobp->state = BG; //The job state is the background.
        printf("[%d] (%d) %s", (jobp->jid), (jobp->pid), (jobp->cmdline)); //Print processing information 'pg. 755'.
    }

  return;
}

/////////////////////////////////////////////////////////////////////////////
//
// waitfg - Block until process pid is no longer the foreground process
//

void waitfg(pid_t pid)
{
    struct job_t *jobp; //Calling the job state in struct '#include jobs.h'
    jobp = getjobpid(jobs, pid); //Assigning the job state '#include jobs.h'
    
    if (jobp != NULL) //If the job is not NULL 'pg. 773'
    {
        while(jobp->state == FG) //Postpone the other processes.
        {
            sleep(1); //Postpone the other processes.
        }
    }
    
    if (pid == 0) //If the job doesn't exist 'pg. 773'
    {
        return; //Return
    }
    
    return;
}

/////////////////////////////////////////////////////////////////////////////
//
// Signal handlers
//
/////////////////////////////////////////////////////////////////////////////
//
// sigchld_handler - The kernel sends a SIGCHLD to the shell whenever
//     a child job terminates (becomes a zombie), or stops because it
//     received a SIGSTOP or SIGTSTP signal. The handler reaps all
//     available zombie children, but doesn't wait for any other
//     currently running children to terminate.  
//

void sigchld_handler(int sig) 
{
    int condition; //Set a status condition
    pid_t pid; //Activate Process ID 'pg.755'
    
    //8.4.3 Reaping Child Processes [Modifying the Default Behavior] 'pg. 743 + 744 + 745'. WNOHANG = Return immediately (with a return value of 0) if none of the child processes in the wait set has terminated yet. The default behavior suspends the calling process until a child terminates; this optin is useful in those cases where I want to continue doing useful work while waiting for a child to terminate. WUNTRACED = Suspend execution of the calling process until a process in the wait set becomes either terminated or stopped. Return the PID of the terminated or stopped child that caused the return. The default behavior returns only for terminated children; this option is useful when I want to check for both terminated and stopped children. WCONTINUED = Suspend execution of the calling process until a running process in the wait set is terminated or until a stopped process in the wait set has been resumed by the receipt of a SIGCONT signal. WNOHANG | WUNTRACED = Return immediately, with a return value of 0, if none of the children in the wait set has stopped or terminated, or with a return value equal to the PID of one of the stopped or terminated children.
    
    //8.4.3 Reaping Child Processes [Checking the Exit Status of a Reaped Child] 'pg. 743 + 744 + 745'. WIFEXITED(status) = Returns true if the child terminated normally, via a call to exit or return. WEXITSTATUS(status) = Returns the exit status of a normally terminated child. This status is only defined if WIFEXITED() returned true. WIFSIGNALED(status) = Returns true if the child process terminated because of a signal that was not caught. WTERMSIG(status) = Returns the number of the signal that caused the child process to terminate. This status is only defined if WIFSIGNALED() returned true. WIFSTOPPED(status) = Returns true if the child that caused the return is currently stopped. WSTOPSIG(status) = Returns the number of the signal that caused the child to stop. This status is only defined is WIFSTOPPED() returned true. WIFCONTINUED(status) = Returns true if the child process was restarted by receipt of a SIGCONT signal.
    
    while((pid = waitpid(fgpid(jobs), &condition, WNOHANG | WUNTRACED)) > 0) //Initiating a While loop reaping child processes 'pg. 743 + 744 + 745'.
    {
        if (WIFSIGNALED(condition)) //WIFSIGNALED detects if the child process has been terminated randomly not by the program.
        {
            printf("Job [%d] (%d) terminated by signal %d\n", pid2jid(pid), pid, WTERMSIG(condition)); //Print terminating process information Process ID to Job ID 'pg. 745 + 755'.
            deletejob(jobs,pid); //Delete the child processor from the job list 'pg. 777'
        }
        
        if (WIFSTOPPED(condition)) //WIFSTOPPED(status) = Returns true if the child that caused the return is currently stopped 'pg. 745'.
        {
            getjobpid(jobs, pid)->state = ST; //Stopping the Job State '#include jobs.h'
            printf("Job [%d] (%d) stopped by signal %d\n", pid2jid(pid), pid, WSTOPSIG(condition)); //Print stopped processing information 'pg. 745 + 755'.
        }
        
        if (WIFEXITED(condition)) //WIFEXITED(status) = Returns true if the child terminated normally, via a call to exit or return 'pg. 745'.
        {
            deletejob(jobs, pid); //Delete the child processor from the job list 'pg. 777'
        }
    }
    
    return;
}

/////////////////////////////////////////////////////////////////////////////

// sigint_handler - The kernel sends a SIGINT to the shell whenver the
//    user types ctrl-c at the keyboard.  Catch it and send it along
//    to the foreground job.  

//8.5.2 Sending Signals [Sending Signals from the Keyboard] 'pg. 759 through pg. 764'. Typing Ctrl+C at the keyboard causes the kernel to send a SIGINT signal to every process in the foreground process group. In the default case, the result is to terminate the foreground job. Similarly, typing Ctrl+Z causes the kernel to send a SIGSTP signal to every process in the foreground process group. In the default case, the result is to stop (suspend) the foreground job.

void sigint_handler(int sig) 
{
    //Ctrl-C immediately terminates (kills) the process using SIGINT 'pg. 763 + 764'.
    
    pid_t pid = fgpid(jobs); //Activate Process ID of the foreground job 'pg.755'.
    
    if (pid != 0) //If the process ID does not equal 0
    {
        kill(-pid, sig); //Kill the process using SIGINT 'pg. 761'.
    }
    
    return;
}

/////////////////////////////////////////////////////////////////////////////
//
// sigtstp_handler - The kernel sends a SIGTSTP to the shell whenever
//     the user types ctrl-z at the keyboard. Catch it and suspend the
//     foreground job by sending it a SIGTSTP.  
//

void sigtstp_handler(int sig) 
{
    //Ctrl-Z causes the kernel to send a SIGSTP signal to every process in the foreground process group. In the default case, the result is to stop (suspend) the foreground job 'pg. 761'.
    
    pid_t pid = fgpid(jobs); //Activate Process ID of the foreground job 'pg.755'.
    
    if (pid != 0) //If the process ID does not equal 0
    {
        kill(-pid, sig); //Kill the process using SIGINT 'pg. 761'.
    }
    
    return;
}

/*********************
 * End signal handlers
 *********************/









