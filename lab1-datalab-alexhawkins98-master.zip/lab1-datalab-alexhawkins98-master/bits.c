/* 
 * CS:APP Data Lab 
 * 
 * <Alex Hawkins 105070938>
 * 
 * bits.c - Source file with your solutions to the Lab.
 *          This is the file you will hand in to your instructor.
 *
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.  
 */

#if 0
/*

 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 
*/

You will provide your solution to the Data Lab by
editing the collection of functions in this source file.

INTEGER CODING RULES:
 
  Replace the "return" statement in each function with one
  or more lines of C code that implements the function. Your code 
  must conform to the following style:
 
  int Funct(arg1, arg2, ...)
  {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >>
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Call any functions.
  5. Use any other operations, such as &&, ||, -, or ?:
  6. Use any form of casting.
  7. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. Uses 2s complement, 32-bit representations of integers.
  2. Performs right shifts arithmetically.
  3. Has unpredictable behavior when shifting an integer by more
     than the word size.

EXAMPLES OF ACCEPTABLE CODING STYLE:

  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
   
  int pow2plus1(int x)
  {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
   
  int pow2plus4(int x)
  {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }

FLOATING POINT CODING RULES

For the problems that require you to implent floating-point operations,
the coding rules are less strict.  You are allowed to use looping and
conditional control.  You are allowed to use both ints and unsigneds.
You can use arbitrary integer and unsigned constants.

You are expressly forbidden to:
  1. Define or use any macros.
  2. Define any additional functions in this file.
  3. Call any functions.
  4. Use any form of casting.
  5. Use any data type other than int or unsigned.  This means that you
     cannot use arrays, structs, or unions.
  6. Use any floating point data types, operations, or constants.


NOTES:
  1. Use the dlc (data lab checker) compiler (described in the handout) to 
     check the legality of your solutions.
  2. Each function has a maximum number of operators (! ~ & ^ | + << >>)
     that you are allowed to use for your implementation of the function. 
     The max operator count is checked by dlc. Note that '=' is not 
     counted; you may use as many of these as you want without penalty.
  3. Use the btest test harness to check your functions for correctness.
  4. Use the BDD checker to formally verify your functions.
  5. The maximum number of ops for each function is given in the
     header comment for each function. If there are any inconsistencies 
     between the maximum ops in the writeup and in this file, consider
     this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *   2. Use the BDD checker to formally verify that your solutions produce 
 *      the correct answers.
 */

#endif
         
/* 
 * bitNor - ~(x|y) using only ~ and & 
 *   Example: bitNor(0x6, 0x5) = 0xFFFFFFF8
 *   Legal ops: ~ &
 *   Max ops: 8
 *   Rating: 1
 */
 
int bitNor(int x, int y)
{   
    return (~x & ~y); //Return the complement of x and y
}

/* 
 * fitsShort - return 1 if x can be represented as a 
 *   16-bit, two's complement integer.
 *   Examples: fitsShort(33000) = 0, fitsShort(-32768) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 8
 *   Rating: 1
 */
 
int fitsShort(int x)
{
    int numberOfShifts = 16; //Created a signed variable (int) named numberOfShifts initialized to 16 (bits)
    int shifting = (x << (numberOfShifts) >> (numberOfShifts)); //Created a signed variable (int) named shifting to move the bits to the left by 16 then arithmetically to the right by 16.
    int result = (shifting ^ x); //Created a signed variable (int) named result to evaluate the result of shifting in exclusive to x.
        
    return !result; //Return the logical notation of the result.
}

/* 
 * thirdBits - return word with every third bit (starting from the LSB) set to 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 8
 *   Rating: 1
 */
 
int thirdBits(void)
{
    int x = 0x49; //Created a signed variable (int) named x equivalent to 0x49. 0x49 evaluates every 3rd bit.
    int w = (x << 9); //Created a signed variable (int) named w to shift x to the left by 9.
    int b = w + x; //Created a signed variable (int) named b to add w & x.
    int z = (b << 18) + b; //Created a signed (int) variable named z to shift b to the left by 18 with another addition operation of b.
    
    return z; //Return z.
}

/* 
 * anyEvenBit - return 1 if any even-numbered bit in word set to 1
 *   Examples anyEvenBit(0xA) = 0, anyEvenBit(0xE) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 2
 */
 
int anyEvenBit(int x)
{
    int w = 0x55; //Created a signed variable (int) named w equivalent to 0x55. 0x55 evaluates every even bit.
    int h = w | (w << 8); //Created a signed variable (int) named h equivalent to w in union of w left shifted by 8.
    int v = h | (h << 16); //Created a signed variable (int) named v equivalent to h in union of h left shifted by 16.
    int m = !!(v & x); //Created a signed variable (int) named m equivalent to the double negation of v & x.
    
    return m; //Return m.
}

/* 
 * copyLSB - set all bits of result to least significant bit of x
 *   Example: copyLSB(5) = 0xFFFFFFFF, copyLSB(6) = 0x00000000
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 5
 *   Rating: 2
 */
 
int copyLSB(int x)
{
    return ((x << 31) >> 31); //Return the operation of x being left shifted by 31 then arithmetically right shifted by 31.
}

/* 
 * implication - return x -> y in propositional logic - 0 for false, 1
 * for true
 *   Example: implication(1,1) = 1
 *            implication(1,0) = 0
 *   Legal ops: ! ~ ^ |
 *   Max ops: 5
 *   Rating: 2
 */
 
int implication(int x, int y)
{
    int v = x ^ y; //Created a signed variable (int) named v to operate x exclusively to y.
    int h = !v; //Created a signed variable (int) named h to operate the logical notation of h.
    int w = y | h; //Created a signed variable (int) named w to evaluate the result of y as a union of h.
    
    return w; //Return w.
}

/* 
 * bitMask - Generate a mask consisting of all 1's 
 *   lowbit and highbit
 *   Examples: bitMask(5,3) = 0x38
 *   Assume 0 <= lowbit <= 31, and 0 <= highbit <= 31
 *   If lowbit > highbit, then mask should be all 0's
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 16
 *   Rating: 3
     
 * Progression:
    * Begin with 0x7fffffff and 0xfffffffe. 31 bits.
        * 01111111 : Right Mask
        * 10000000 : Left Mask
         
    * Right shift the right mask to the lowbit.
    * Left shift the left mask to the highbit.
    * Utilize the | operator to make the identified
        * region 0s while the other bits are 1s.
    * Utilize the negation to make the correct format of bits.

*/
 
int bitMask(int highbit, int lowbit)
{
    int msb = ~(1 << 31); //Created a signed variable (int) named msb set to 0x7fffffff. 31 bits 4 bytes.
    int lsb = ~1; //Created a signed variable (int) named lsb set to 0xfffffffe. 31 bits 4 bytes.
    
    int low = (31 + (~lowbit + 1)); //Created a signed variable (int) named low to evaluate the lowbit.
    int lowrider = (msb >> low); //Created a signed variable (int) named lowrider to evaluate the msb right shifted by low.
    
    int high = (lsb << highbit); //Created a signed variable (int) named high set to left shift lsb by highbit.
    int highrider = ~(high | lowrider); //Created a signed variable (int) named highrider set to the complemented union of high and lowrider.
    
    return highrider; //Return highrider.
}

/*
 * ezThreeFourths - multiplies by 3/4 rounding toward 0,
 *   Should exactly duplicate effect of C expression (x*3/4),
 *   including overflow behavior.
 *   Examples: ezThreeFourths(11) = 8
 *             ezThreeFourths(-9) = -6
 *             ezThreeFourths(1073741824) = -268435456 (overflow)
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 3
 */
 
int ezThreeFourths(int x)
{   
    int m = (x + (x << 1)); //Created a signed variable (int) named m set to left shift x by 1 in addition to x.
    int operate = m >> 31; //Created a signed variable (int) named operate set to right shift m by 31.
    int w = (m + (3 & operate)); //Created a signed variable (int) named w set to evaluate the intersection of 3 and operate in addition to m.
    int threeFour = (w >> 2); //Created a signed variable (int) named threeFour set to right shift w by 2.
    
    return threeFour; //Return threeFour.
}

/*
 * satMul3 - multiplies by 3, saturating to Tmin or Tmax if overflow
 *  Examples: satMul3(0x10000000) = 0x30000000
 *            satMul3(0x30000000) = 0x7FFFFFFF (Saturate to TMax)
 *            satMul3(0x70000000) = 0x7FFFFFFF (Saturate to TMax)
 *            satMul3(0xD0000000) = 0x80000000 (Saturate to TMin)
 *            satMul3(0xA0000000) = 0x80000000 (Saturate to TMin)
 *  Legal ops: ! ~ & ^ | + << >>
 *  Max ops: 25
 *  Rating: 3
 */
 
int satMul3(int x)
{
    return 2; //Return 2.
}

/*
 * bitParity - returns 1 if x contains an odd number of 0's
 *   Examples: bitParity(5) = 0, bitParity(7) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 4
 
 * Progression:
    * Reduce the exclusive or representation of two numbers
        * in half until there is only one bit left.
    * Calculate the intersection (&) representation of x and 0x1 to return
        * the LSB of 1 if the calculation contains an odd number of 0's in
        * its binary values or a 0 if the calculation contains an even
        * number of 0's in its binary value.
    * BitLab Recitation Video
 */
 
int bitParity(int x)
{
    int w = x; //Created a signed variable (int) named w set to x.
    
    w = w ^ (w >> 16); //Reducing the exclusive or representation of w in half.
    w = w ^ (w >> 8); //Reducing the exclusive or representation of w in half.
    w = w ^ (w >> 4); //Reducing the exclusive or representation of w in half.
    w = w ^ (w >> 2); //Reducing the exclusive or representation of w in half.
    w = w ^ (w >> 1); //Reducing the exclusive or representation of w in half.
    w = (w & 0x1); //Calculating the intersection representation of x and 0x1.
    
    return w; //Return w.
}

/*
 * ilog2 - return floor(log base 2 of x), where x > 0
 *   Example: ilog2(16) = 4
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 90
 *   Rating: 4
 */
 
int ilog2(int x)
{
    int score = 0; //Created a signed variable (int) named score set to 0.
    
    score = !!(x >> 16) << 4; //Calculating the double negation of x right shifted by 16 in association to a left shift by 4.
    score = ((!!(x >> (score + 8))) << 3) + score; //Calculating the double negation of x right shifted by score in association to a left shift by 3.
    score = ((!!(x >> (score + 4))) << 2) + score; //Calculating the double negation of x right shifted by score in association to a left shift by 2.
    score = ((!!(x >> (score + 2))) << 1) + score; //Calculating the double negation of x right shifted by score in association to a left shift by 1.
    score = ((!!(x >> (score + 1))) << 0) + score; //Calculating the double negation of x right shifted by score in association to a left shift by 0.
    
    return score; //Return score.
}

/*
 * trueThreeFourths - multiplies by 3/4 rounding toward 0,
 *   avoiding errors due to overflow
 *   Examples: trueThreeFourths(11) = 8
 *             trueThreeFourths(-9) = -6
 *             trueThreeFourths(1073741824) = 805306368 (no overflow)
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 4
 */
 
int trueThreeFourths(int x)
{
    int vvs = x; //Created a signed variable (int) named vvs set to x.
    int hddn = (x & 3); //Created a signed variable (int) named hddn set to the intersection of x and 3.
    int operate = (x >> 31); //Created a signed variable (int) named operate set to right shift x by 31.
    
    vvs = (vvs >> 0x2); //vvs is set to right shift by 0x2.
    vvs = vvs + (vvs << 0x1); //vvs is set to left shift by 0x1 in addition to vvs.
    vvs = vvs + ((hddn + (hddn << 0x1) + (operate & 0x3)) >> 0x2); //vvs is set to the left shift of hhdn 
    // by 0x1 in addition to the intersection of operate and 0x3, in all together, right shifting by 0x2.
    
    return vvs; //Return vvs.
}


/*
 * Extra credit
 */
 
 
/* 
 * float_neg - Return bit-level equivalent of expression -f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representations of
 *   single-precision floating point values.
 *   When argument is NaN, return argument.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 10
 *   Rating: 2
 */
 
unsigned float_neg(unsigned uf)
{
     return 2; //Return 2.
}

/* 
 * float_i2f - Return bit-level equivalent of expression (float) x
 *   Result is returned as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point values.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
 
unsigned float_i2f(int x)
{
  return 2; //Return 2.
}

/* 
 * float_twice - Return bit-level equivalent of expression 2*f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
 
unsigned float_twice(unsigned uf)
{
  return 2; //Return 2.
}